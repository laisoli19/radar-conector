// Radar Conector (Chrome): o código da extensão foi escrito para o Firefox,
// que usa "browser.*". Este arquivo faz a mesma coisa funcionar no Chrome,
// que usa "chrome.*": as respostas às mensagens, as abas (sem os containers,
// que só existem no Firefox) e o armazenamento.
(() => {
  const g = typeof globalThis !== "undefined" ? globalThis : self;
  if (g.browser && g.browser.runtime && g.browser.runtime.getBrowserInfo) return; // é o Firefox
  const c = g.chrome;
  if (!c || !c.runtime) return;

  // O Chrome não conhece containers: o campo é tirado antes de chegar nele.
  const semContainer = (o) => {
    if (!o || typeof o !== "object") return o;
    const { cookieStoreId, ...resto } = o;
    return resto;
  };

  // No Firefox, quem ouve uma mensagem responde devolvendo uma Promise. No
  // Chrome, a resposta vai por sendResponse: aqui uma coisa vira a outra.
  const embrulhados = new Map();
  const onMessage = {
    addListener(fn) {
      const w = (msg, sender, sendResponse) => {
        let r;
        try {
          r = fn(msg, sender);
        } catch (e) {
          return false;
        }
        if (r && typeof r.then === "function") {
          r.then(
            (v) => { try { sendResponse(v); } catch (e) {} },
            () => { try { sendResponse(undefined); } catch (e) {} }
          );
          return true;
        }
        if (r !== undefined) {
          try { sendResponse(r); } catch (e) {}
        }
        return false;
      };
      embrulhados.set(fn, w);
      c.runtime.onMessage.addListener(w);
    },
    removeListener(fn) {
      const w = embrulhados.get(fn);
      if (w) c.runtime.onMessage.removeListener(w);
      embrulhados.delete(fn);
    },
  };

  g.browser = {
    runtime: {
      getManifest: () => c.runtime.getManifest(),
      getURL: (p) => c.runtime.getURL(p),
      sendMessage: (m) => c.runtime.sendMessage(m),
      onMessage,
      onInstalled: c.runtime.onInstalled,
    },
    storage: c.storage,
    tabs: c.tabs
      ? {
          query: (q) => c.tabs.query(semContainer(q)),
          create: (p) => c.tabs.create(semContainer(p)),
          update: (id, p) => c.tabs.update(id, p),
          remove: (id) => c.tabs.remove(id),
          get: (id) => c.tabs.get(id),
          sendMessage: (id, m, o) => (o ? c.tabs.sendMessage(id, m, o) : c.tabs.sendMessage(id, m)),
        }
      : undefined,
    windows: c.windows,
    // Sem containers no Chrome: tudo acontece no WhatsApp Web normal.
    contextualIdentities: {
      query: async () => [],
      get: async () => null,
      create: async () => ({ cookieStoreId: "firefox-default" }),
    },
  };
})();
