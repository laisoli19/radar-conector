// Radar Conector (Chrome): um WhatsApp Web só. O botão abre (ou mostra) a aba
// fixada do WhatsApp Web; a linha de cima diz se ele está conectado.
const $ = (id) => document.getElementById(id);
const ROTULO = {
  conectado: ["Conectado", "ok"],
  qr: ["Precisa do QR Code", "erro"],
  carregando: ["Carregando...", "esp"],
  fechado: ["Aba fechada", "esp"],
};

async function mostrarEstado() {
  const r = await browser.runtime.sendMessage({ tipo: "status", containers: ["whatsapp"] }).catch(() => null);
  const estado = (r && r.lista && r.lista[0] && r.lista[0].estado) || "fechado";
  const [texto, cls] = ROTULO[estado] || [estado, "esp"];
  $("estado").textContent = texto;
  $("estado").className = cls;
}

$("abrir").addEventListener("click", async () => {
  await browser.runtime.sendMessage({ tipo: "ir-para", container: "whatsapp" }).catch(() => {});
  window.close();
});

$("copiarMembros").addEventListener("click", async () => {
  const [aba] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!aba || !/web\.whatsapp\.com/.test(aba.url || "")) return alert("Abra o grupo no WhatsApp Web e clique de novo.");
  browser.tabs.sendMessage(aba.id, { tipo: "copiar-membros" }).catch(() => {});
  window.close();
});

mostrarEstado();
setInterval(mostrarEstado, 3000);
