// Radar Conector: formulário "Criação de Negócios | Pré-Vendas Contador".
// Preenche com os dados do lead enviados pelo Meu Radar e avisa quando foi enviado.
(() => {
  const limpa = (t) => String(t || "").replace(/\s+/g, " ").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const CAMPOS = [
    ["sdr", /sdr|insira seu e-?mail/],
    ["empresa", /nome da empresa/],
    ["outro", /outro telefone/],
    ["whatsapp", /whatsapp/],
    ["cnpj", /cnpj/],
    ["estado", /^estado|^uf\b/],
    ["cidade", /^cidade/],
    ["email", /^e-?mail/],
    ["nome", /^nome\b/],
  ];
  const ESTADOS = { AC:"Acre",AL:"Alagoas",AP:"Amapá",AM:"Amazonas",BA:"Bahia",CE:"Ceará",DF:"Distrito Federal",ES:"Espírito Santo",GO:"Goiás",MA:"Maranhão",MT:"Mato Grosso",MS:"Mato Grosso do Sul",MG:"Minas Gerais",PA:"Pará",PB:"Paraíba",PR:"Paraná",PE:"Pernambuco",PI:"Piauí",RJ:"Rio de Janeiro",RN:"Rio Grande do Norte",RS:"Rio Grande do Sul",RO:"Rondônia",RR:"Roraima",SC:"Santa Catarina",SP:"São Paulo",SE:"Sergipe",TO:"Tocantins" };
  const controleDo = (lb) => {
    if (lb.htmlFor) { const el = document.getElementById(lb.htmlFor); if (el) return el; }
    const box = lb.closest(".hs-form-field, .field, fieldset, div");
    return box ? box.querySelector("input:not([type=hidden]), select, textarea") : null;
  };
  const escrever = (el, v) => {
    if (!el || v == null || v === "") return;
    if (el.tagName === "SELECT") {
      const alvo = limpa(v), nome = limpa(ESTADOS[String(v).toUpperCase()] || "");
      const op = [...el.options].find((o) => [limpa(o.value), limpa(o.text)].some((x) => x && (x === alvo || (nome && x === nome))));
      if (!op) return;
      el.value = op.value;
    } else {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    }
    ["input", "change", "blur"].forEach((t) => el.dispatchEvent(new Event(t, { bubbles: true })));
  };
  const preencher = (d) => {
    const labels = [...document.querySelectorAll("label")];
    if (labels.length < 4) return false;
    const usados = new Set();
    for (const lb of labels) {
      const t = limpa(lb.textContent);
      const campo = CAMPOS.find(([, re]) => re.test(t));
      if (!campo || usados.has(campo[0])) continue;
      const el = controleDo(lb);
      if (!el) continue;
      usados.add(campo[0]);
      escrever(el, d[campo[0]]);
    }
    return usados.size >= 4;
  };
  let avisou = false;
  const enviado = () => {
    if (avisou) return;
    avisou = true;
    browser.runtime.sendMessage({ tipo: "hsform-enviado" }).catch(() => {});
  };
  window.addEventListener("message", (e) => {
    const d = e.data || {};
    if (d.type === "hsFormCallback" && d.eventName === "onFormSubmitted") enviado();
  });
  const SUCESSO = /seu neg[oó]cio ser[aá] criado|agora [eé] s[oó] conferir sua tela de neg[oó]cios|obrigad[oa] por|thanks for submitting/i;
  setInterval(() => {
    if (!avisou && document.body && SUCESSO.test(document.body.innerText || "") && !document.querySelector("form input:not([type=hidden])")) enviado();
  }, 800);
  browser.runtime.sendMessage({ tipo: "hsform-dados" }).then((r) => {
    if (!r || !r.dados) return;
    const fim = Date.now() + 20000;
    const tentar = () => { if (preencher(r.dados)) return; if (Date.now() < fim) setTimeout(tentar, 500); };
    tentar();
  }).catch(() => {});
})();
