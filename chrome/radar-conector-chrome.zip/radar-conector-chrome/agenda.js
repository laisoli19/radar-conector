// Radar Conector: página de reuniões da Nibo. Guarda o e-mail do lead e avisa
// o Meu Radar quando o Calendly confirma que a reunião foi agendada.
// Na lista "Reuniões agendadas" do contato, lê também a reunião mais recente
// (consultor, dia e horário), para o Radar ficar certo mesmo quando o
// agendamento ou o reagendamento não foi visto na hora.
(() => {
  let email = "";
  const lerEmail = () => {
    try {
      const p = new URLSearchParams(location.search);
      const e = (p.get("contato") || "").trim();
      if (e) email = e;
    } catch (e) {}
    return email;
  };
  lerEmail();
  setInterval(lerEmail, 1500);
  window.addEventListener("message", (ev) => {
    if (!/^https:\/\/([a-z0-9-]+\.)?calendly\.com$/i.test(ev.origin || "")) return;
    const d = ev.data || {};
    if (d.event !== "calendly.event_scheduled") return;
    browser.runtime.sendMessage({ tipo: "agenda-concluida", email: lerEmail(), via: "evento" }).catch(() => {});
  });
  // Para o Calendly (dentro da página) saber de qual lead é a reunião.
  browser.runtime.onMessage.addListener((m) => {
    if (m && m.tipo === "agenda-qual-email") return Promise.resolve({ email: lerEmail() });
  });

  // ---- Lista "Reuniões agendadas" ----
  // Ex.: "Reunião com o vendedor Mateus Francisco Braga Gonçalves no dia 10 nov. 2026 às 17:25"
  //      "Marcado por fulano@nibo.com.br e acaba às 18:15"
  const MESES = { jan: 1, fev: 2, mar: 3, abr: 4, mai: 5, jun: 6, jul: 7, ago: 8, set: 9, out: 10, nov: 11, dez: 12 };
  const ITEM = /Reuni[aã]o com o vendedor\s+(.+?)\s+no dia\s+(\d{1,2})\s+(?:de\s+)?([a-zç]{3})[a-zç]*\.?\s+(?:de\s+)?(\d{4})\s+[àa]s\s+(\d{1,2}:\d{2})(?:[\s\S]{0,160}?acaba [àa]s\s+(\d{1,2}:\d{2}))?/gi;
  let ultimaLista = "";
  const lerLista = () => {
    if (!/\/reunioes\/lista/i.test(location.pathname)) return;
    const mail = lerEmail();
    if (!mail) return;
    const texto = (document.body && document.body.innerText) || "";
    let maisNova = null;
    for (const m of texto.matchAll(ITEM)) {
      const mes = MESES[m[3].toLowerCase()];
      if (!mes) continue;
      const data = m[4] + "-" + String(mes).padStart(2, "0") + "-" + m[2].padStart(2, "0");
      const r = { data, inicio: m[5].padStart(5, "0"), fim: m[6] ? m[6].padStart(5, "0") : "", consultor: m[1].trim() };
      if (!maisNova || r.data + r.inicio > maisNova.data + maisNova.inicio) maisNova = r;
    }
    if (!maisNova) return;
    const chave = mail.toLowerCase() + "|" + maisNova.data + "|" + maisNova.inicio + "|" + maisNova.consultor;
    if (chave === ultimaLista) return;
    ultimaLista = chave;
    browser.runtime.sendMessage({ tipo: "agenda-lista", email: mail, ...maisNova }).catch(() => {});
  };
  let ag = null;
  new MutationObserver(() => { if (!ag) ag = setTimeout(() => { ag = null; lerLista(); }, 500); }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  setInterval(lerLista, 3000);
})();
