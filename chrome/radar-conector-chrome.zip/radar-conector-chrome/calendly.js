// Radar Conector: dentro do Calendly da página de reuniões da Nibo.
// Lê o dia e o horário escolhidos, percebe a tela de confirmação e, nela,
// pega o nome do consultor (vendedor) que ficou com a reunião.
(() => {
  if (window.top === window) return; // só quando está dentro da página da Nibo
  const MESES = { janeiro: 1, fevereiro: 2, "março": 3, marco: 3, abril: 4, maio: 5, junho: 6, julho: 7, agosto: 8, setembro: 9, outubro: 10, novembro: 11, dezembro: 12,
    january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
  const RE = /(\d{1,2}:\d{2})\s*[-–]\s*(\d{1,2}:\d{2}),\s*[^,\n]+,\s*(\d{1,2})\s+(?:de\s+)?([a-zçA-ZÇ]+)\s+(?:de\s+)?(\d{4})/;
  const CONFIRMADO = /voc[eê] est[aá] agendad|agendamento confirmado|reuni[aã]o agendada|you are scheduled|this meeting is scheduled|confirmed/i;
  // Linhas que nunca são o nome do consultor.
  const NAO_NOME = /\d|revezamento|vendedor|reuni[aã]o|convite|agendad|hor[aá]rio|webconfer|detalhes|calendly|\bmin\b|@/i;

  // Na confirmação, o consultor é a linha logo acima do dia e horário
  // (ex.: "Revezamento comercial" / "Antonio Gonçalves" / "17:10 - 18:00, ...").
  const consultorDe = (texto) => {
    const linhas = texto.split("\n").map((l) => l.trim()).filter(Boolean);
    const i = linhas.findIndex((l) => RE.test(l));
    if (i < 1) return "";
    const nome = linhas[i - 1];
    if (nome.length < 3 || nome.length > 60 || NAO_NOME.test(nome)) return "";
    return nome;
  };

  let ultima = null, avisou = false;
  const ler = () => {
    const t = (document.body && document.body.innerText) || "";
    const m = t.match(RE);
    if (m) {
      const mes = MESES[m[4].toLowerCase()];
      if (mes) {
        const data = m[5] + "-" + String(mes).padStart(2, "0") + "-" + m[3].padStart(2, "0");
        const nova = { data, inicio: m[1].padStart(5, "0"), fim: m[2].padStart(5, "0") };
        if (!ultima || ultima.data !== nova.data || ultima.inicio !== nova.inicio) {
          ultima = nova;
          browser.runtime.sendMessage({ tipo: "agenda-data", ...nova }).catch(() => {});
        }
      }
    }
    // Tela final do Calendly: só conta depois de ter lido um horário.
    if (ultima && !avisou && CONFIRMADO.test(t) && !/agendar evento|schedule event/i.test(t)) {
      avisou = true;
      browser.runtime.sendMessage({ tipo: "agenda-concluida", via: "tela", ...ultima, consultor: consultorDe(t) }).catch(() => {});
    }
  };
  let ag = null;
  new MutationObserver(() => { if (!ag) ag = setTimeout(() => { ag = null; ler(); }, 300); }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  setInterval(ler, 2000);
})();
