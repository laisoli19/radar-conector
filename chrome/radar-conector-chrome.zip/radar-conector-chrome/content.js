// Radar Conector (teste): roda dentro do WhatsApp Web. Pega a fila salva pelo
// botão da extensão e, um número de cada vez, abre a conversa com a mensagem,
// clica em enviar e espera o intervalo sorteado antes do próximo.

(() => {
  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
  let ocupado = false;

  const ler = async () => (await browser.storage.local.get("radar")).radar || null;
  const gravar = (radar) => browser.storage.local.set({ radar });

  // Um aviso pequeno no canto do WhatsApp Web, para você ver o que está acontecendo.
  const aviso = document.createElement("div");
  aviso.style.cssText =
    "position:fixed;right:12px;bottom:12px;z-index:99999;background:#16191a;color:#f1f5f4;border-radius:10px;padding:8px 12px;font:12px system-ui,sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.3);display:none;max-width:260px";
  document.documentElement.appendChild(aviso);
  const mostrar = (texto) => {
    aviso.textContent = texto;
    aviso.style.display = texto ? "block" : "none";
  };

  // O WhatsApp Web muda os nomes internos do botão de enviar de tempos em
  // tempos; por isso procuramos por vários nomes e, por último, por qualquer
  // ícone de "send" dentro da conversa aberta.
  const botaoEnviar = () => {
    const icone =
      document.querySelector('span[data-icon="send"]') ||
      document.querySelector('span[data-icon="wds-ic-send-filled"]') ||
      document.querySelector('#main [data-icon*="send" i]:not([data-icon*="sticker" i])');
    return (
      icone?.closest("button") ||
      icone?.closest('[role="button"]') ||
      document.querySelector('#main button[aria-label="Enviar"], #main [role="button"][aria-label="Enviar"]') ||
      document.querySelector('#main button[aria-label="Send"], #main [role="button"][aria-label="Send"]') ||
      document.querySelector('button[aria-label="Enviar"]') ||
      document.querySelector('button[aria-label="Send"]') ||
      null
    );
  };

  const caixaMensagem = () =>
    document.querySelector('footer div[contenteditable="true"]') ||
    document.querySelector('div[contenteditable="true"][data-tab="10"]') ||
    document.querySelector('#main div[contenteditable="true"][role="textbox"]') ||
    [...document.querySelectorAll('#main div[contenteditable="true"]')].pop() ||
    null;

  // Enter de verdade na caixa da mensagem (usado quando o botão não aparece).
  const apertarEnter = (el) => {
    if (!el) return;
    el.focus();
    const op = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent("keydown", op));
    el.dispatchEvent(new KeyboardEvent("keypress", op));
    el.dispatchEvent(new KeyboardEvent("keyup", op));
  };

  // A janelinha do WhatsApp dizendo que o número não tem WhatsApp
  // ("O número +55 ... não está no WhatsApp." / OK). O WhatsApp novo tem
  // outras janelas com role="dialog" escondidas na página, então aqui olhamos
  // TODAS as janelas visíveis, e também sobe a partir de um botão "OK".
  const FRASE_INVALIDO = /não está no whatsapp|nao esta no whatsapp|isn['’]t on whatsapp|is not on whatsapp|not on whatsapp|no está en whatsapp|número de telefone compartilhado.*inválido|phone number shared via url is invalid|inválido|invalid/i;
  const visivel = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
  const avisoInvalido = () => {
    const janelas = document.querySelectorAll(
      '[role="dialog"], [role="alertdialog"], [data-animate-modal-popup="true"], [data-animate-modal-body="true"]'
    );
    for (const j of janelas) {
      if (visivel(j) && FRASE_INVALIDO.test(j.innerText || "")) return j;
    }
    // Plano B: um botão "OK" visível cuja janela fala do número sem WhatsApp.
    for (const b of document.querySelectorAll('button, [role="button"]')) {
      if (!/^\s*ok\s*$/i.test(b.innerText || "") || !visivel(b)) continue;
      let p = b;
      for (let i = 0; i < 8 && p; i++) {
        p = p.parentElement;
        if (p && FRASE_INVALIDO.test(p.innerText || "") && (p.innerText || "").length < 400) return p;
      }
    }
    return null;
  };
  // Fecha o aviso: clica no OK (ou no único botão); se não achar, aperta Esc.
  const fecharInvalido = (janela) => {
    const j = janela || avisoInvalido();
    if (!j) return false;
    const botoes = [...j.querySelectorAll('button, [role="button"]')].filter(visivel);
    const ok = botoes.find((b) => /^\s*ok\s*$/i.test(b.innerText || "")) || botoes[botoes.length - 1];
    if (ok) ok.click();
    else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
    return true;
  };
  // Espera um pouco o aviso aparecer (o WhatsApp consulta o número antes de mostrar).
  const aguardarInvalido = async (ms) => {
    const limite = Date.now() + ms;
    while (Date.now() < limite) {
      if (avisoInvalido()) return true;
      await esperar(300);
    }
    return false;
  };

  const urlDoItem = (radar, indice) => {
    const item = radar.fila[indice];
    const versoes = radar.mensagens || [""];
    const texto = versoes[indice % versoes.length];
    return `https://web.whatsapp.com/send?phone=${item.tel}&text=${encodeURIComponent(texto)}`;
  };

  // Texto "limpo" para comparar: sem espaços extras nem caracteres invisíveis.
  const limpo = (t) => String(t || "").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, " ").trim();
  const caixaVazia = () => { const c = caixaMensagem(); return !c || !limpo(c.innerText); };
  // Mensagens que EU enviei na conversa aberta (balões do lado direito).
  const minhas = () => {
    const porId = [...document.querySelectorAll('#main [data-id^="true_"]')].filter((el) => !(el.parentElement && el.parentElement.closest('#main [data-id]')));
    if (porId.length) return porId;
    return [...document.querySelectorAll("#main .message-out")];
  };
  // Quantas vezes o começo do texto aparece na conversa (sem contar a caixa de digitar).
  const vezesNaConversa = (inicio) => {
    if (!inicio) return 0;
    const main = document.querySelector("#main");
    if (!main) return 0;
    const conta = (t) => limpo(t).split(inicio).length - 1;
    const rodape = main.querySelector("footer");
    return conta(main.innerText) - (rodape ? conta(rodape.innerText) : 0);
  };
  // Linhas de mensagem da conversa (no WhatsApp novo o data-id não começa mais
  // com "true_", então olhamos todas as linhas e comparamos com antes do envio).
  const linhas = () => [...document.querySelectorAll("#main [data-id]")].filter((el) => !(el.parentElement && el.parentElement.closest("#main [data-id]")));
  // Só letras e números, sem acento: emoji vira imagem no balão e some do texto.
  const soLetras = (t) => String(t || "").normalize("NFD").replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
  const temIconeEnvio = (el) => !!el.querySelector('[data-icon="msg-time"], [data-icon="msg-check"], [data-icon^="msg-dblcheck"], [data-icon="status-check"], [data-icon="status-dblcheck"], [data-icon*="check" i]');
  // Foto da conversa antes de enviar, para comparar depois.
  const fotoAntes = (inicio) => ({ baloes: minhas().length, vezes: vezesNaConversa(inicio), ids: new Set(linhas().map((el) => el.getAttribute("data-id"))), chave: soLetras(inicio).slice(0, 15) });
  // Linha nova (que não existia antes do envio) com o começo do texto, ou com o
  // relógio/tique de mensagem minha enquanto a caixa já está vazia.
  const linhaNova = (antes) => {
    const novas = linhas().filter((el) => !antes.ids.has(el.getAttribute("data-id")));
    if (!novas.length) return false;
    if (antes.chave && novas.some((el) => soLetras(el.textContent).includes(antes.chave))) return true;
    return caixaVazia() && novas.some(temIconeEnvio);
  };
  // Enviado SÓ quando a mensagem aparece de verdade na conversa: um balão meu
  // novo com o começo do texto, ou o texto aparecendo uma vez a mais na conversa.
  // A caixa ficar vazia sozinha NÃO conta como enviado.
  const aguardarBalao = async (antes, inicio, ms) => {
    const limite = Date.now() + ms;
    while (Date.now() < limite) {
      const lista = minhas();
      if (lista.length > antes.baloes) {
        const ultimo = limpo(lista[lista.length - 1].innerText);
        if (!inicio || ultimo.includes(inicio)) return true;
      }
      if (inicio && vezesNaConversa(inicio) > antes.vezes) return true;
      if (antes.ids && linhaNova(antes)) return true;
      await esperar(400);
    }
    return false;
  };

  // Depois do envio, confere se a mensagem saiu do celular: com o relógio
  // (msg-time) ela ainda não saiu; com um ou dois tiques, saiu. Se o relógio
  // continuar por 20 s, o número está sem conexão e o envio volta como "parado".
  const confirmarSaida = async () => {
    const limite = Date.now() + 20000;
    let viuRelogio = false;
    while (Date.now() < limite) {
      const lista = minhas();
      const ultimo = lista[lista.length - 1];
      if (!ultimo) return "enviado";
      if (ultimo.querySelector('[data-icon="msg-check"], [data-icon^="msg-dblcheck"], [data-icon="status-check"], [data-icon="status-dblcheck"]')) return "enviado";
      if (ultimo.querySelector('[data-icon="msg-time"]')) viuRelogio = true;
      else if (!viuRelogio) return "enviado";
      await esperar(500);
    }
    return viuRelogio ? "parado" : "enviado";
  };

  async function tentarEnviar(telefone) {
    const limite = Date.now() + 60000;
    let textoPronto = 0; // quando a caixa apareceu com o texto, mas sem o botão
    while (Date.now() < limite) {
      const invalido = avisoInvalido();
      if (invalido) {
        fecharInvalido(invalido);
        return "invalido";
      }
      const botao = botaoEnviar();
      const caixa = caixaMensagem();
      // Texto na caixa e nenhum botão de enviar por 4 s: envia com o Enter,
      // uma única vez (nunca envia duas vezes).
      if (!botao && caixa && limpo(caixa.innerText)) {
        if (!textoPronto) textoPronto = Date.now();
        else if (Date.now() - textoPronto > 4000) {
          if (await aguardarInvalido(1500)) {
            fecharInvalido();
            return "invalido";
          }
          const inicio = limpo(caixa.innerText).slice(0, 25);
          const antes = fotoAntes(inicio);
          apertarEnter(caixa);
          if (await aguardarBalao(antes, inicio, 12000)) return await confirmarSaida();
          // Internet lenta: se a caixa esvaziou, espera mais um pouco o balão.
          if (caixaVazia() && (await aguardarBalao(antes, inicio, 8000))) return await confirmarSaida();
          return "erro";
        }
      } else textoPronto = 0;
      if (botao && caixa && limpo(caixa.innerText)) {
        // Dá um instante para o aviso de número sem WhatsApp, se ele vier atrasado.
        if (await aguardarInvalido(1500)) {
          fecharInvalido();
          return "invalido";
        }
        await esperar(800 + Math.random() * 1200);
        const inicio = limpo(caixa.innerText).slice(0, 25);
        const antes = fotoAntes(inicio);
        botao.click();
        // Enviado = apareceu a mensagem na conversa (até 12 s, para internet lenta).
        if (await aguardarBalao(antes, inicio, 12000)) return await confirmarSaida();
        const depois = caixaMensagem();
        if (depois && limpo(depois.innerText)) {
          // O clique não pegou e o texto continua na caixa: tenta o Enter uma única vez.
          apertarEnter(depois);
          if (await aguardarBalao(antes, inicio, 8000)) return await confirmarSaida();
        } else if (await aguardarBalao(antes, inicio, 8000)) {
          // A caixa esvaziou mas o balão ainda não apareceu: espera mais um pouco.
          return await confirmarSaida();
        }
        // A mensagem não apareceu na conversa: NÃO conta como enviada.
        return "erro";
      }
      mostrar(`Radar Conector: abrindo a conversa com +${telefone}...`);
      await esperar(1000);
    }
    return "erro";
  }

  // Abrir a conversa POR DENTRO do WhatsApp já carregado, sem recarregar a
  // página: um link de conversa é clicado dentro do app. Se o WhatsApp não
  // tratar o clique, nada acontece (a extensão volta para o jeito antigo).
  async function abrirPorDentro(telefone, texto) {
    const enderecos = [
      `https://web.whatsapp.com/send?phone=${telefone}&text=${encodeURIComponent(texto || "")}`,
      `https://wa.me/${telefone}?text=${encodeURIComponent(texto || "")}`,
      `https://api.whatsapp.com/send?phone=${telefone}&text=${encodeURIComponent(texto || "")}`,
    ];
    let tratado = false;
    for (const href of enderecos) {
      const a = document.createElement("a");
      a.href = href;
      a.rel = "noopener noreferrer";
      a.style.display = "none";
      (document.querySelector("#app") || document.body).appendChild(a);
      let foi = false;
      const conferir = (e) => {
        if (e.target !== a) return;
        foi = e.defaultPrevented;
        if (!e.defaultPrevented) e.preventDefault();
      };
      window.addEventListener("click", conferir, false);
      a.click();
      window.removeEventListener("click", conferir, false);
      a.remove();
      if (foi) {
        tratado = true;
        break;
      }
    }
    if (!tratado) return "falhou";
    const inicio = String(texto || "").trim().slice(0, 15);
    const limite = Date.now() + 12000;
    while (Date.now() < limite) {
      if (avisoInvalido()) return "invalido";
      const caixa = caixaMensagem();
      const escrito = (caixa?.innerText || "").trim();
      if (caixa && (!inicio || escrito.startsWith(inicio))) return "ok";
      await esperar(300);
    }
    // Última olhada: o aviso pode ter chegado no fim da espera.
    return avisoInvalido() ? "invalido" : "falhou";
  }

  // Segundo caminho rápido: "Nova conversa" → digita o número na busca →
  // clica no resultado → cola a mensagem na caixa. Tudo sem recarregar.
  const clicarIcone = (...nomes) => {
    for (const nome of nomes) {
      const icone = document.querySelector(`span[data-icon="${nome}"]`);
      const alvo = icone?.closest("button") || icone?.closest('[role="button"]') || icone?.parentElement;
      if (alvo) {
        alvo.click();
        return true;
      }
    }
    const porRotulo = document.querySelector('[aria-label="Nova conversa"], [title="Nova conversa"], [aria-label="New chat"], [title="New chat"]');
    if (porRotulo) {
      porRotulo.click();
      return true;
    }
    return false;
  };

  const escrever = (el, texto) => {
    el.focus();
    try {
      const dados = new DataTransfer();
      dados.setData("text/plain", texto);
      const colar = new ClipboardEvent("paste", { clipboardData: dados, bubbles: true, cancelable: true });
      el.dispatchEvent(colar);
      if ((el.innerText || el.value || "").trim()) return;
    } catch (e) {}
    try {
      document.execCommand("insertText", false, texto);
    } catch (e) {}
  };

  const fecharPainel = () => {
    document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
  };

  async function abrirPelaBusca(telefone, texto) {
    if (!clicarIcone("new-chat-outline", "new-chat", "chat-filled-refreshed", "wds-ic-new-chat")) return "falhou";
    await esperar(900);
    const campo = document.activeElement && (document.activeElement.isContentEditable || document.activeElement.tagName === "INPUT")
      ? document.activeElement
      : null;
    if (!campo) {
      fecharPainel();
      return "falhou";
    }
    const local = telefone.startsWith("55") ? telefone.slice(2) : telefone;
    escrever(campo, local);
    // Espera o resultado com o fim do número (ou o único resultado da busca).
    const fim = local.slice(-4);
    let resultado = null;
    const limite = Date.now() + 6000;
    while (Date.now() < limite && !resultado) {
      await esperar(400);
      const itens = [...document.querySelectorAll('[role="listitem"], [role="gridcell"], [role="button"][tabindex]')].filter(
        (el) => el.offsetParent && !el.closest("footer") && (el.innerText || "").replace(/\D/g, "").includes(fim)
      );
      resultado = itens[0] || null;
    }
    if (!resultado) {
      fecharPainel();
      return "falhou";
    }
    resultado.click();
    const limiteCaixa = Date.now() + 5000;
    while (Date.now() < limiteCaixa) {
      const caixa = caixaMensagem();
      if (caixa) {
        if (texto) {
          escrever(caixa, texto);
          await esperar(500);
          const escrito = (caixaMensagem()?.innerText || "").trim();
          if (!escrito) return "falhou";
        }
        return "ok";
      }
      await esperar(300);
    }
    return "falhou";
  }

  // Tenta os dois caminhos rápidos; o aviso no canto mostra qual funcionou.
  async function abrirRapido(telefone, texto) {
    // Se ficou aberto o aviso de um número anterior sem WhatsApp, fecha antes,
    // senão ele bloqueia a conversa seguinte.
    if (fecharInvalido()) await esperar(600);
    ultimoAberto = { tel: String(telefone || "").replace(/\D/g, ""), quando: Date.now() };
    setTimeout(lembrarTitulo, 2500);
    setTimeout(lembrarTitulo, 6000);
    let r = await abrirPorDentro(telefone, texto);
    if (r !== "falhou") {
      mostrar("Radar Conector: aberto sem recarregar (link)");
      return r;
    }
    r = await abrirPelaBusca(telefone, texto);
    mostrar(r === "falhou" ? "Radar Conector: recarregando a conversa..." : "Radar Conector: aberto sem recarregar (busca)");
    setTimeout(() => mostrar(""), 3000);
    return r;
  }

  // Diz se o WhatsApp Web desta aba está logado, mostrando o QR Code ou carregando.
  const estadoAtual = () => {
    if (
      document.querySelector("#pane-side") ||
      document.querySelector('[data-testid="chat-list"]') ||
      document.querySelector('div[aria-label="Lista de conversas"]') ||
      document.querySelector('div[aria-label="Chat list"]')
    )
      return "conectado";
    if (document.querySelector("div[data-ref]") || document.querySelector("canvas[aria-label]")) return "qr";
    return "carregando";
  };

  // ---- Copiar membros do grupo: telefone, nome e recado de cada participante ----
  const TEL_RE = /\+\d{1,3}[\s\d()-]{8,}\d/;
  const soDig = (t) => String(t || "").replace(/\D/g, "");
  const textoVisivel = (el) => (el?.getAttribute?.("title") || el?.textContent || "").trim();
  const nomeDoGrupo = () => {
    const h = document.querySelector("#main header");
    const s = h && (h.querySelector('span[dir="auto"]') || h.querySelector("span"));
    return textoVisivel(s);
  };
  // Lista de membros aberta (janela "Ver tudo" ou painel "Dados do grupo"): o bloco rolável com mais linhas.
  const caixaDeMembros = () => {
    let melhor = null, linhas = 0;
    document.querySelectorAll("div").forEach((d) => {
      if (d.scrollHeight <= d.clientHeight + 20 || d.clientHeight < 150) return;
      const st = getComputedStyle(d).overflowY;
      if (st !== "auto" && st !== "scroll") return;
      if (d.closest("#main") || d.closest("#pane-side")) return;
      const n = d.querySelectorAll('[role="listitem"], [role="row"], [role="button"]').length;
      if (n > linhas) { linhas = n; melhor = d; }
    });
    return melhor;
  };
  const lerLinhas = (caixa, mapa) => {
    caixa.querySelectorAll('[role="listitem"], [role="row"], [role="button"]').forEach((li) => {
      if (li.parentElement && li.parentElement.closest('[role="listitem"], [role="row"]') && caixa.contains(li.parentElement.closest('[role="listitem"], [role="row"]'))) return;
      const tudo = li.innerText || "";
      const m = tudo.match(TEL_RE);
      if (!m) return;
      const tel = soDig(m[0]);
      if (tel.length < 10 || mapa.has(tel)) return;
      const partes = [...li.querySelectorAll("span[title], span[dir='auto']")].map(textoVisivel).filter(Boolean);
      const unicos = [...new Set(partes)].filter((t) => !TEL_RE.test(t) && !/^admin do grupo$|^group admin$/i.test(t) && t !== "Você" && t !== "You");
      // Nome: o que vem com "~" (nome do perfil) ou, em contato salvo, o título principal da linha.
      // Quando o título principal é o próprio telefone e não há "~nome", a pessoa não tem nome: o texto que sobra é o recado.
      const principal = partes[0] || "";
      const comTil = unicos.find((t) => /^~/.test(t));
      let nome = comTil ? comTil.replace(/^~\s*/, "") : (!TEL_RE.test(principal) && unicos[0] === principal ? principal : "");
      const recadoBruto = unicos.find((t) => t !== comTil && t !== principal && t.length > 1) || (nome ? "" : unicos[0] || "");
      const GENERICO = /^(dispon[ií]vel|ocupado|available|busy|ol[aá]!? eu estou usando o whatsapp( business)?\.?|hey there! i am using whatsapp\.?|urgent calls only)$/i;
      if (GENERICO.test(nome)) nome = "";
      const recado = GENERICO.test(recadoBruto) ? "" : recadoBruto;
      mapa.set(tel, { tel, nome, recado });
    });
  };
  async function copiarMembros() {
    const grupo = nomeDoGrupo();
    const mapa = new Map();
    const caixa = caixaDeMembros();
    if (caixa) {
      caixa.scrollTop = 0;
      await esperar(500);
      let parado = 0, antes = -1;
      for (let i = 0; i < 400 && parado < 4; i++) {
        lerLinhas(caixa, mapa);
        mostrar(`Radar Conector: lendo membros... ${mapa.size}`);
        const fim = caixa.scrollTop + caixa.clientHeight >= caixa.scrollHeight - 5;
        if (mapa.size === antes && fim) parado++; else parado = 0;
        antes = mapa.size;
        caixa.scrollTop += Math.max(200, caixa.clientHeight * 0.8);
        await esperar(450);
      }
    }
    // Complemento: números que aparecem no topo do grupo.
    const h = document.querySelector("#main header");
    if (h) {
      const t = [...h.querySelectorAll("[title]")].map((e) => e.getAttribute("title")).join(",") + "," + h.innerText;
      (t.match(/\+\d{1,3}[\s\d()-]{8,}\d/g) || []).forEach((x) => { const tel = soDig(x); if (tel.length >= 10 && !mapa.has(tel)) mapa.set(tel, { tel, nome: "", recado: "" }); });
    }
    mostrar("");
    const limpa = (t) => String(t || "").replace(/[\t\r\n]+/g, " ").trim();
    const linhas = ["Telefone\tContato\tRecado\tOrigem", ...[...mapa.values()].map((p) => [p.tel, limpa(p.nome), limpa(p.recado), limpa("Grupo WhatsApp: " + grupo)].join("\t"))];
    painelCopiar(mapa.size, grupo, linhas.join("\n"), !!caixa);
    return mapa.size;
  }
  // Janelinha com o resultado e o botão Copiar (o clique é o que libera copiar para a área de transferência).
  function painelCopiar(qtd, grupo, texto, leuLista) {
    document.getElementById("radar-membros")?.remove();
    const p = document.createElement("div");
    p.id = "radar-membros";
    p.style.cssText = "position:fixed;right:16px;top:16px;z-index:99999;background:#fff;color:#0f172a;border:1px solid #cbd5e1;border-radius:10px;padding:12px;width:280px;font:12px system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.18)";
    const t = document.createElement("div"); t.style.cssText = "font-weight:600;margin-bottom:4px"; t.textContent = `${qtd} membros encontrados`;
    const s = document.createElement("div"); s.style.cssText = "color:#64748b;margin-bottom:10px"; s.textContent = leuLista ? grupo : "Só os números do topo. Para pegar nome e recado, abra Dados do grupo > Ver tudo e use de novo.";
    const b = document.createElement("button"); b.textContent = "Copiar"; b.style.cssText = "width:100%;height:30px;border-radius:7px;border:1px solid #1f3d2e;background:#1f3d2e;color:#fff;font-weight:600;cursor:pointer";
    const f = document.createElement("button"); f.textContent = "Fechar"; f.style.cssText = "width:100%;height:28px;margin-top:6px;border-radius:7px;border:1px solid #cbd5e1;background:#fff;cursor:pointer";
    b.onclick = () => navigator.clipboard.writeText(texto).then(() => { b.textContent = "Copiado"; setTimeout(() => p.remove(), 1500); }).catch(() => { b.textContent = "Não consegui copiar"; });
    f.onclick = () => p.remove();
    p.append(t, s, b, f);
    document.documentElement.appendChild(p);
  }

  browser.runtime.onMessage.addListener((msg) => {
    if (msg.tipo === "copiar-membros") return copiarMembros().then((n) => ({ ok: true, n }));
    if (msg.tipo === "puxar") {
      return puxar(msg.telefone, msg.pedido);
    }
    if (msg.tipo === "estado") {
      return Promise.resolve({ estado: estadoAtual() });
    }
    if (msg.tipo === "abrir-conversa") {
      return abrirRapido(msg.telefone, msg.texto).then((r) => ({ ok: r === "ok", status: r }));
    }
    if (msg.tipo === "enviar-aqui") {
      return (async () => {
        const r = await abrirRapido(msg.telefone, msg.texto);
        if (r === "falhou") return { status: "falhou" };
        if (r === "invalido") {
          fecharInvalido();
          mostrar("Radar Conector: número sem WhatsApp");
          setTimeout(() => mostrar(""), 4000);
          return { status: "invalido" };
        }
        const status = await tentarEnviar(msg.telefone);
        mostrar(status === "enviado" ? "Radar Conector: enviado ✓" : status === "parado" ? "Radar Conector: mensagem parada no relógio (número sem conexão)" : "Radar Conector: não consegui enviar");
        setTimeout(() => mostrar(""), 4000);
        return { status };
      })();
    }
  });

  // Pedido do Meu Radar (disparo automático): a extensão abriu esta aba na
  // conversa do contato; aqui ela clica em enviar e devolve o resultado.
  let tarefaFeita = false;
  async function tarefaDoRadar() {
    if (tarefaFeita) return false;
    let t = null;
    try {
      t = await browser.runtime.sendMessage({ tipo: "minha-tarefa" });
    } catch (e) {}
    if (!t) return false;
    tarefaFeita = true;
    const status = await tentarEnviar(t.telefone);
    mostrar(status === "enviado" ? "Radar Conector: enviado ✓" : status === "invalido" ? "Radar Conector: número sem WhatsApp" : status === "parado" ? "Radar Conector: mensagem parada no relógio (número sem conexão)" : "Radar Conector: não consegui enviar");
    setTimeout(() => mostrar(""), 4000);
    try {
      await browser.runtime.sendMessage({ tipo: "resultado", id: t.id, status });
    } catch (e) {}
    return true;
  }

  async function rodar() {
    if (ocupado) return;
    ocupado = true;
    try {
      if (await tarefaDoRadar()) return;
      const radar = await ler();
      if (!radar || !radar.ativo) {
        mostrar("");
        return;
      }
      const fila = radar.fila || [];
      const enviando = fila.findIndex((i) => i.status === "enviando");

      // A conversa de um número já foi aberta: hora de clicar em enviar. O
      // WhatsApp tira o número do endereço depois de abrir a conversa, então
      // aqui vale o horário em que ela foi aberta, e não o endereço.
      if (enviando >= 0) {
        const item = fila[enviando];
        if (!item.abertoEm) {
          radar.fila[enviando] = { ...item, abertoEm: Date.now() };
          await gravar(radar);
          location.href = urlDoItem(radar, enviando);
          return;
        }
        let resultado = "erro";
        if (Date.now() - item.abertoEm < 90000) resultado = await tentarEnviar(item.tel);
        const atual = (await ler()) || radar;
        atual.fila[enviando] = { ...atual.fila[enviando], status: resultado, quando: new Date().toISOString() };
        const segundos = atual.min + Math.random() * (atual.max - atual.min);
        atual.proximoEm = Date.now() + segundos * 1000;
        if (!atual.fila.some((i) => i.status === "pendente")) atual.ativo = false;
        await gravar(atual);
        return;
      }

      const proximo = fila.findIndex((i) => i.status === "pendente");
      if (proximo < 0) {
        mostrar("Radar Conector: teste concluído.");
        await gravar({ ...radar, ativo: false });
        return;
      }

      const falta = Math.ceil((radar.proximoEm - Date.now()) / 1000);
      const feitos = fila.filter((i) => i.status !== "pendente").length;
      if (falta > 0) {
        mostrar(`Radar Conector: ${feitos} de ${fila.length} · próximo em ${falta}s`);
        return;
      }

      radar.fila[proximo] = { ...radar.fila[proximo], status: "enviando", abertoEm: Date.now() };
      await gravar(radar);
      location.href = urlDoItem(radar, proximo);
    } catch (e) {
      console.error("Radar Conector", e);
    } finally {
      ocupado = false;
    }
  }

  // Espera o WhatsApp Web carregar antes de começar.
  const inicio = Date.now();
  const comecar = setInterval(() => {
    const pronto = document.querySelector("#app") && (document.querySelector("#pane-side") || caixaMensagem() || document.querySelector('div[role="dialog"]') || document.querySelector('[data-icon="new-chat-outline"]') || document.querySelectorAll('[role="listitem"], [role="row"]').length > 2);
    if (pronto || Date.now() - inicio > 25000) {
      clearInterval(comecar);
      setInterval(rodar, 1500);
      rodar();
    }
  }, 1000);

  // ---- Ligações pelo WhatsApp ----
  // Percebe a janelinha de chamada do WhatsApp Web (Ligando… / Chamando… /
  // cronômetro / botão Desligar) e, quando ela some, avisa a extensão com o
  // número, se foi atendida e quanto durou.
  const SO_DIGITOS = (t) => String(t || "").replace(/\D/g, "");
  const botaoDesligar = () =>
    document.querySelector('[aria-label="Desligar"], [aria-label="End call"], [aria-label="Encerrar chamada"], [title="Desligar"], [title="End call"]');
  const painelChamada = () => {
    const b = botaoDesligar();
    if (!b) return null;
    let p = b;
    for (let i = 0; i < 8 && p; i++) {
      p = p.parentElement;
      if (p && /\+?\d[\d\s()-]{9,}/.test(p.textContent || "")) return p;
    }
    return b.parentElement;
  };
  // Grupo, lista de transmissão, canal ou status: nunca pertence a um lead.
  const ID_NAO_INDIVIDUAL = /@g\.us|@broadcast|@newsletter|status@/i;
  const conversaEhIndividual = () => {
    const main = document.querySelector("#main");
    if (!main) return false;
    const ids = [...main.querySelectorAll("[data-id]")].slice(-40).map((e) => e.getAttribute("data-id") || "");
    if (ids.some((id) => ID_NAO_INDIVIDUAL.test(id))) return false;
    if (main.querySelector('header [data-icon*="group" i], header [data-icon*="community" i], header [data-icon*="newsletter" i]')) return false;
    // WhatsApp novo: o data-id não traz mais "@g.us". Sinais de grupo pelo cabeçalho e pelas mensagens.
    const h = main.querySelector("header");
    const txtCab = (h?.textContent || "");
    if (/dados do grupo|group info|clique (aqui )?para (ver )?(os )?dados|click here for group|\bvocê\b|\byou\b/i.test(txtCab.replace(tituloConversa(), " "))) return false;
    if ((txtCab.match(/\+?\d[\d\s()-]{9,}/g) || []).length > 1) return false;
    if (/,/.test(txtCab.replace(tituloConversa(), "")) && /\+?\d[\d\s()-]{9,}|,.*,/.test(txtCab.replace(tituloConversa(), ""))) return false;
    // Mensagens recebidas de mais de um autor = grupo.
    const autores = new Set();
    main.querySelectorAll("[data-pre-plain-text]").forEach((e) => {
      const m = (e.getAttribute("data-pre-plain-text") || "").match(/\]\s*([^:]+):\s*$/);
      if (m && !e.closest(".message-out")) autores.add(m[1].trim());
    });
    if (autores.size > 1) return false;
    if (main.querySelector(".message-in [data-testid*='author' i], .message-in span[aria-label*='Talvez' i], .message-in span[aria-label*='Maybe' i]")) return false;
    return true;
  };
  // Se um grupo aberto tinha ficado ligado a um lead pelo nome, desfaz a ligação.
  const esquecerTituloSeGrupo = () => {
    if (conversaEhIndividual()) return;
    const t = tituloConversa();
    if (t && nomeParaTel.has(t)) {
      nomeParaTel.delete(t);
      browser.storage.local.set({ nomeParaTel: [...nomeParaTel] }).catch(() => {});
    }
  };
  const numeroDoCabecalho = () => {
    if (!conversaEhIndividual()) return "";
    // Só o título da conversa vale (o subtítulo pode listar outras pessoas).
    const t = (typeof tituloConversa === "function" ? tituloConversa() : "");
    const m = t.match(/\+?\d[\d\s()-]{9,}/);
    if (m) return SO_DIGITOS(m[0]);
    return (t && typeof nomeParaTel !== "undefined" && nomeParaTel.get(t)) || "";
  };
  // Contatos que aparecem com nome (ex.: conta comercial) em vez do número:
  // guardamos nome da conversa -> telefone quando o Meu Radar abre a conversa.
  const tituloConversa = () => {
    const h = document.querySelector("#main header");
    const s = h && (h.querySelector('span[dir="auto"]') || h.querySelector("span"));
    return (s?.textContent || "").trim();
  };
  const nomeParaTel = new Map();
  browser.storage.local.get("nomeParaTel").then((r) => (r.nomeParaTel || []).forEach(([k, v]) => nomeParaTel.set(k, v))).catch(() => {});
  let ultimoAberto = { tel: "", quando: 0 };
  const lembrarTitulo = () => {
    if (!ultimoAberto.tel || Date.now() - ultimoAberto.quando > 20000) return;
    if (!conversaEhIndividual()) return;
    const t = tituloConversa();
    if (!t || /\d{8,}/.test(t.replace(/\D/g, ""))) return;
    if (nomeParaTel.get(t) !== ultimoAberto.tel) {
      nomeParaTel.set(t, ultimoAberto.tel);
      browser.storage.local.set({ nomeParaTel: [...nomeParaTel].slice(-2000) }).catch(() => {});
    }
  };
  const lerSegundos = (t) => {
    const m = String(t || "").match(/\b(\d{1,2}):(\d{2})(?::(\d{2}))?\b/);
    if (!m) return null;
    return m[3] != null ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : (+m[1]) * 60 + (+m[2]);
  };
  // Lê o último balão "Ligação de voz" da conversa aberta.
  const ultimoBalao = () => {
    const balas = [...document.querySelectorAll("#main [role='row'], #main .message-out, #main .message-in")].filter((e) =>
      /Ligação de voz|Voice call|Chamada de voz/i.test(e.textContent || "")
    );
    const t = balas.length ? balas[balas.length - 1].textContent || "" : "";
    if (/Não atendida|Missed|Sem resposta/i.test(t)) return { resultado: "nao_atendida" };
    if (/Recusada|Declined/i.test(t)) return { resultado: "recusada" };
    let seg = 0;
    const h = t.match(/(\d+)\s*hora/i), mi = t.match(/(\d+)\s*min/i), s = t.match(/(\d+)\s*seg/i);
    if (h) seg += +h[1] * 3600;
    if (mi) seg += +mi[1] * 60;
    if (s) seg += +s[1];
    return seg ? { resultado: "atendeu", segundos: seg } : null;
  };
  let chamada = null;
  setInterval(() => {
    const p = painelChamada();
    if (p) {
      const txt = p.textContent || "";
      if (!chamada) {
        const m = txt.match(/\+?\d[\d\s()-]{9,}/);
        chamada = { telefone: m ? SO_DIGITOS(m[0]) : numeroDoCabecalho(), inicio: new Date().toISOString(), atendeu: false, segundos: 0 };
      }
      // Cronômetro: um texto curto e exato tipo "0:16" ou "1:02:05" dentro da janelinha.
      const folhas = [...p.querySelectorAll("span, div")].filter((e) => e.children.length === 0);
      const tempo = folhas.map((e) => (e.textContent || "").trim()).find((t) => /^\d{1,2}:\d{2}(?::\d{2})?$/.test(t));
      if (tempo) {
        const s = lerSegundos(tempo);
        if (!chamada.atendeu) chamada.inicioConversa = Date.now() - (s || 0) * 1000;
        chamada.atendeu = true;
        if (s != null) chamada.segundos = Math.max(chamada.segundos, s);
      }
      return;
    }
    if (!chamada) return;
    const fim = chamada;
    chamada = null;
    if (fim.atendeu && fim.inicioConversa) fim.segundos = Math.max(fim.segundos, Math.round((Date.now() - fim.inicioConversa) / 1000) - 1);
    setTimeout(() => {
      const b = ultimoBalao();
      let resultado = fim.atendeu ? "atendeu" : "nao_atendida";
      let segundos = fim.segundos;
      if (b && b.resultado !== "atendeu" && !fim.atendeu) resultado = b.resultado;
      if (b && b.resultado === "atendeu") {
        resultado = "atendeu";
        segundos = Math.max(segundos, b.segundos || 0);
      }
      if (!fim.telefone) return;
      browser.runtime
        .sendMessage({
          tipo: "ligacao-wa",
          ligacao: {
            id: "wa-" + fim.telefone + "-" + fim.inicio,
            telefone: fim.telefone,
            inicio: fim.inicio,
            fim: new Date().toISOString(),
            resultado,
            segundos,
          },
        })
        .catch(() => {});
    }, 2500);
  }, 1000);


  // ---- Conversas: lê as mensagens da conversa aberta e manda ao Meu Radar ----
  const DIAS = ["domingo","segunda-feira","terça-feira","quarta-feira","quinta-feira","sexta-feira","sábado"];
  const iso = (d) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  const dataDoSeparador = (t) => {
    t = String(t || "").trim().toLowerCase();
    const hoje = new Date();
    if (t === "hoje" || t === "today") return iso(hoje);
    if (t === "ontem" || t === "yesterday") { const d = new Date(hoje); d.setDate(d.getDate() - 1); return iso(d); }
    const m = t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (m) return m[3] + "-" + m[2].padStart(2, "0") + "-" + m[1].padStart(2, "0");
    const i = DIAS.indexOf(t);
    if (i >= 0) { const d = new Date(hoje); let k = (d.getDay() - i + 7) % 7; if (k === 0) k = 7; d.setDate(d.getDate() - k); return iso(d); }
    return null;
  };
  const telefoneDoId = (id) => { const m = String(id || "").match(/^(?:true|false)_(\d{10,15})@c\.us/); return m ? m[1] : ""; };
  // Mensagem citada (resposta a outra mensagem): o quadro de cima com a mensagem original.
  // Tudo que está dentro dele é ignorado, para valer só o que a pessoa escreveu.
  const SEL_CITACAO = "[data-testid*='quoted'], .quoted-mention, [aria-label*='citada' i], [aria-label*='quoted' i]";
  const citacoesDe = (el) => {
    const lista = [];
    el.querySelectorAll(SEL_CITACAO).forEach((q) => {
      const caixa = q.closest("[role='button']");
      lista.push(caixa && el.contains(caixa) && caixa !== el ? caixa : q);
    });
    return lista;
  };
  const fora = (lista, cits) => (cits.length ? lista.filter((x) => !cits.some((c) => c.contains(x))) : lista);
  const textoSemCitacao = (el, cits) => {
    if (!cits.length) return el.textContent || "";
    let t = el.textContent || "";
    cits.forEach((c) => { t = t.replace(c.textContent || "", " "); });
    return t;
  };
  const tipoDaMensagem = (el, cits = []) => {
    const icones = fora([...el.querySelectorAll("[data-icon]")], cits).map((x) => x.getAttribute("data-icon") || "").join(" ");
    const rot = fora([...el.querySelectorAll("[aria-label]")], cits).map((x) => x.getAttribute("aria-label") || "").join(" ");
    const txt = textoSemCitacao(el, cits);
    if (/audio|ptt/i.test(icones) || /mensagem de voz|voice message|áudio|audio/i.test(rot) || fora([...el.querySelectorAll("audio")], cits).length) return "audio";
    // Vídeo: ícone/rótulo de vídeo, tag <video>, ou miniatura com a duração escrita por cima
    // (dois horários curtos na mensagem: a duração do vídeo e a hora do envio).
    const curtos = fora([...el.querySelectorAll("span, div")], cits).filter((x) => x.children.length === 0 && /^\d{1,2}:\d{2}$/.test((x.textContent || "").trim()));
    const temMiniatura = fora([...el.querySelectorAll("img, canvas, video, [style*='background-image']")], cits).some((i) => !i.alt && (i.getBoundingClientRect().width || i.naturalWidth || 0) >= 80);
    if (/video|media-play|media-gif/i.test(icones) || /v[ií]deo/i.test(rot) || fora([...el.querySelectorAll("video")], cits).length || (temMiniatura && curtos.length >= 2)) return "video";
    if (/document|pdf|doc-|xls|ppt/i.test(icones) || /\.(pdf|docx?|xlsx?|pptx?|csv|txt|zip|rar|xml|ofx)\b/i.test(txt)) return "documento";
    if (/sticker|figurinha/i.test(icones + " " + rot)) return "figurinha";
    const imgs = fora([...el.querySelectorAll("img")], cits).filter((i) => !i.alt && (i.getBoundingClientRect().width || i.naturalWidth || 0) >= 80);
    if (imgs.length || /image|imagem|foto|photo/i.test(rot)) return "foto";
    return "texto";
  };
  const ROTULO_MIDIA = { audio: "🎤 Áudio", video: "🎬 Vídeo", documento: "📄 Documento", foto: "📷 Foto", figurinha: "🙂 Figurinha" };
  // Minha mensagem fica do lado direito da conversa; a do lead, do lado esquerdo.
  const ehMinha = (el) => {
    const main = document.querySelector("#main");
    if (!main) return false;
    const m = main.getBoundingClientRect();
    // Acha o balão: o maior bloco dentro da mensagem que não ocupa a largura toda.
    let melhor = null, area = 0;
    [el, ...el.querySelectorAll("div")].forEach((d) => {
      const r = d.getBoundingClientRect();
      if (r.width < 40 || r.height < 16 || r.width > m.width * 0.85) return;
      const a = r.width * r.height;
      if (a > area) { area = a; melhor = r; }
    });
    if (!melhor) return false;
    return melhor.left + melhor.width / 2 > m.left + m.width / 2;
  };
  let vistos = new Set();
  const assinatura = new Map();
  let sujo = false;
  setInterval(() => {
    if (!sujo) return;
    sujo = false;
    browser.storage.local.set({ msgVistas4: [...vistos].slice(-5000), msgAssin: [...assinatura].slice(-5000) }).catch(() => {});
  }, 5000);
  browser.storage.local.get(["msgVistas4", "msgAssin"]).then((r) => {
    (r.msgVistas4 || []).forEach((x) => vistos.add(x));
    (r.msgAssin || []).forEach(([k, v]) => assinatura.set(k, v));
  }).catch(() => {});
  const lerConversa = () => {
    const main = document.querySelector("#main");
    if (!main) return 0;
    if (!conversaEhIndividual()) { esquecerTituloSeGrupo(); return 0; }
    const telCab = numeroDoCabecalho();
    let dataAtual = null;
    const novas = [];
    const nos = main.querySelectorAll("[data-id], div[role='row'], span, div");
    const itens = main.querySelectorAll("[data-id]");
    // Separadores de data da conversa ("Hoje", "Ontem", "quarta-feira", "22/10/2026"), na ordem da tela.
    const seps = [...main.querySelectorAll("span, div")].filter(
      (e) => e.children.length === 0 && !e.closest("[data-id]") && (e.textContent || "").trim().length < 25 && dataDoSeparador(e.textContent)
    );
    const dataPelaPosicao = (el) => {
      let d = null;
      for (const s of seps) {
        if (s.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) d = dataDoSeparador(s.textContent);
        else break;
      }
      return d;
    };
    itens.forEach((el) => {
      if (el.parentElement && el.parentElement.closest("#main [data-id]")) return;
      const bruto = el.getAttribute("data-id") || "";
      if (!bruto || ID_NAO_INDIVIDUAL.test(bruto)) return;
      const eu = /^true_/.test(bruto) || ehMinha(el) || !!el.closest(".message-out") || !!el.querySelector(".message-out") ||
        !!el.querySelector('[data-icon="msg-dblcheck"], [data-icon="msg-check"], [data-icon="msg-time"], [data-icon^="msg-dblcheck"], [data-icon="status-dblcheck"], [data-icon="status-check"]');
      const pre = el.querySelector("[data-pre-plain-text]")?.getAttribute("data-pre-plain-text") || "";
      const mp = pre.match(/\[(\d{1,2}:\d{2}),\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\]/);
      let hora = mp ? mp[1] : "";
      let data = mp ? mp[4] + "-" + mp[3].padStart(2, "0") + "-" + mp[2].padStart(2, "0") : (dataPelaPosicao(el) || dataAtual);
      if (mp) dataAtual = data;
      if (!hora) { const h = (el.textContent || "").match(/(\d{1,2}:\d{2})(?!.*\d{1,2}:\d{2})/); hora = h ? h[1] : ""; }
      if (!data) data = iso(new Date());
      const cits = citacoesDe(el);
      const tudo = textoSemCitacao(el, cits);
      const apagada = /mensagem apagada|apagou esta mensagem|mensagem foi apagada|message was deleted|you deleted this message|deleted message/i.test(tudo) || !!el.querySelector('[data-icon*="recall"]');
      const editada = /\bEditada\b|\bEdited\b/.test(tudo);
      const tipo = apagada ? "apagada" : tipoDaMensagem(el, cits);
      let texto = "";
      // O texto da pessoa é o último bloco de texto fora da citação.
      let cand = fora([...el.querySelectorAll(".selectable-text")], cits).filter((x) => (x.innerText || x.textContent || "").trim());
      if (!cand.length) cand = fora([...el.querySelectorAll("[data-pre-plain-text] span, .copyable-text span")], cits).filter((x) => !x.querySelector("span") && (x.textContent || "").trim() && !/^\d{1,2}:\d{2}$/.test((x.textContent || "").trim()));
      const sel = cand[cand.length - 1];
      if (sel) texto = sel.innerText || sel.textContent || "";
      if (apagada) texto = "Mensagem apagada";
      else if (tipo !== "texto") texto = ROTULO_MIDIA[tipo] + (texto ? " · " + texto : "");
      else if (!texto.trim()) {
        // Sem texto e sem tipo reconhecido: é algum anexo. Registra para não sumir.
        const ehChamada = /Ligação de voz|Ligação de vídeo|Chamada de voz|Chamada de vídeo|Voice call|Video call/i.test(tudo);
        const temMidia = el.querySelector("img, canvas, video, [style*='background-image']");
        if (temMidia && !ehChamada) { texto = "Anexo"; }
      }
      texto = texto.trim();
      if (!texto) return;
      const telefone = telefoneDoId(bruto) || telCab;
      if (!telefone) return;
      const id = telefone + "_" + bruto;
      const sig = "v2|" + (eu ? "eu" : "lead") + "|" + tipo + "|" + texto.slice(0, 200);
      if (vistos.has(id) && assinatura.get(id) === sig) return;
      // Só conta como alteração se já foi lida com a leitura nova (v2); lidas antes, como a
      // resposta citada que tinha ficado de fora, entram como mensagem nova.
      const mudou = vistos.has(id) && String(assinatura.get(id) || "").startsWith("v2|");
      vistos.add(id);
      assinatura.set(id, sig);
      novas.push({ id, telefone, de: eu ? "eu" : "lead", texto: texto.slice(0, 2000), tipo, data, hora, editada: editada || undefined, atualizacao: mudou || undefined });
    });
    if (novas.length) {
      sujo = true;
      browser.runtime.sendMessage({ tipo: "mensagens-wa", mensagens: novas }).catch(() => {});
    }
    return itens.length;
  };
  let agendado = null;
  const lerLogo = () => {
    if (agendado) return;
    agendado = setTimeout(() => { agendado = null; lerConversa(); }, 250);
  };
  new MutationObserver(lerLogo).observe(document.body, { childList: true, subtree: true });
  setInterval(lerConversa, 4000);

  // Quem respondeu: lê a lista de conversas (lado esquerdo) e manda ao Meu Radar
  // as conversas com mensagem não lida, com nome, telefone, prévia, hora e quantidade.
  const lerNaoLidas = () => {
    const itens = [];
    const linhas = document.querySelectorAll("#pane-side [role='listitem'], #pane-side [role='row'], #pane-side [role='gridcell']");
    const vistosLinha = new Set();
    linhas.forEach((li) => {
      const badge = li.querySelector('[aria-label*="não lida" i], [aria-label*="não lidas" i], [aria-label*="unread" i]');
      if (!badge) return;
      const raiz = li.closest("[role='listitem']") || li;
      if (vistosLinha.has(raiz)) return;
      if (raiz.querySelector('[data-icon*="group" i], [data-icon*="community" i], [data-icon*="newsletter" i]')) return;
      vistosLinha.add(raiz);
      const titulos = [...raiz.querySelectorAll("span[title]")].map((x) => x.getAttribute("title") || "").filter(Boolean);
      const nome = (titulos[0] || "").trim();
      const previa = (titulos[1] || "").trim();
      const digitos = nome.replace(/\D/g, "");
      const telefone = digitos.length >= 10 ? digitos : (nomeParaTel.get(nome) || "");
      const hora = ((raiz.textContent || "").match(/\b\d{1,2}:\d{2}\b|Ontem|Yesterday/) || [""])[0];
      const qtd = parseInt((badge.textContent || "").replace(/\D/g, ""), 10) || 1;
      if (nome) itens.push({ nome, telefone, previa: previa.slice(0, 200), hora, qtd });
    });
    browser.runtime.sendMessage({ tipo: "respostas", itens }).catch(() => {});
  };
  setInterval(lerNaoLidas, 8000);
  setTimeout(lerNaoLidas, 3000);

  // Puxar conversa antiga: abre a conversa e rola para cima até o começo.
  async function puxar(telefone, pedido) {
    const r = await abrirRapido(telefone, "");
    if (r === "falhou" || r === "invalido") return { ok: false, motivo: r };
    await esperar(1500);
    const contar = () => document.querySelectorAll("#main [data-id]").length;
    let parado = 0, ultimo = contar();
    for (let i = 0; i < 150 && parado < 4; i++) {
      const rows = document.querySelectorAll("#main [data-id]");
      const primeira = rows[0];
      let rolavel = primeira;
      while (rolavel && rolavel !== document.body && !(rolavel.scrollHeight > rolavel.clientHeight + 10 && getComputedStyle(rolavel).overflowY !== "visible")) rolavel = rolavel.parentElement;
      if (rolavel && rolavel !== document.body) rolavel.scrollTop = 0;
      else primeira?.scrollIntoView({ block: "start" });
      // Espera só até o WhatsApp carregar mais mensagens (no máximo 2 s).
      let n = contar();
      for (let t = 0; t < 10 && n === ultimo; t++) {
        await esperar(200);
        n = contar();
      }
      lerConversa();
      parado = n === ultimo ? parado + 1 : 0;
      ultimo = n;
      browser.runtime.sendMessage({ tipo: "puxar-progresso", pedido, lidas: n }).catch(() => {});
    }
    lerConversa();
    return { ok: true, lidas: ultimo };
  }

})();
