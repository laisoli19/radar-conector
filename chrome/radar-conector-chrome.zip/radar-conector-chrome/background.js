// Radar Conector (Chrome): a mesma extensão do Firefox, para o Meu Radar Chrome,
// com um WhatsApp Web só (sem containers). Recebe do Meu Radar o pedido de envio,
// abre a conversa POR DENTRO do WhatsApp Web já aberto (sem recarregar a página)
// e devolve ao Meu Radar o resultado: enviado, invalido (número sem WhatsApp),
// desconectado (WhatsApp pedindo QR Code) ou erro.
importScripts("compat.js");

const tarefas = new Map(); // aba do WhatsApp -> tarefa

function responder(origem, id, status, motivo = "", container = undefined) {
  if (origem == null) return;
  const extra = container !== undefined ? { container } : {};
  browser.tabs.sendMessage(origem, { tipo: "resultado", id, status, motivo, ...extra }).catch(() => {});
}

// O número que envia é sempre o que o Meu Radar pediu (a regra de "cada lead
// fala sempre pelo mesmo número" fica só no Radar). A trava antiga da 0.7.0,
// guardada na extensão, é apagada na instalação/atualização.
browser.runtime.onInstalled.addListener(() => {
  browser.storage.local.remove("donos").catch(() => {});
});
async function fecharEnvio(origem, id, telefone, container, status, motivo = "") {
  responder(origem, id, status, motivo, container);
}

// No Chrome não há containers: todo número é o WhatsApp Web normal deste Chrome.
async function cookieStoreDe() {
  return "firefox-default";
}

const esperarMs = (ms) => new Promise((r) => setTimeout(r, ms));

// A aba do WhatsApp Web deste Chrome. Se não houver, abre uma (fixada, sem
// tirar você da tela) e espera ela carregar — no máximo 60 s.
async function abaDoWhatsApp() {
  let abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*" });
  if (abas.length) return abas[0];
  await browser.tabs.create({ url: "https://web.whatsapp.com/", pinned: true, active: false });
  const fim = Date.now() + 60000;
  while (Date.now() < fim) {
    await esperarMs(2000);
    abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (abas.length) {
      const e = await browser.tabs.sendMessage(abas[0].id, { tipo: "estado" }).catch(() => null);
      if (e && e.estado !== "carregando") return abas[0];
    }
  }
  return abas[0] || null;
}

// Envio do Disparo: sempre por dentro do WhatsApp Web já aberto, sem recarregar
// a página. Se a conversa não abrir por dentro, o envio volta como erro (o Meu
// Radar trata como trata hoje) — a página nunca é recarregada para enviar.
async function enviar(msg, origem) {
  try {
    const aba = await abaDoWhatsApp();
    if (!aba) {
      responder(origem, msg.id, "erro", "aba");
      return;
    }
    // WhatsApp desconectado (tela do QR Code): avisa o Meu Radar e não tenta enviar.
    const e = await browser.tabs.sendMessage(aba.id, { tipo: "estado" }).catch(() => null);
    if (e && e.estado === "qr") {
      responder(origem, msg.id, "desconectado", "qr");
      return;
    }
    const r = await browser.tabs.sendMessage(aba.id, { tipo: "enviar-aqui", telefone: msg.telefone, texto: msg.texto || "" }).catch(() => null);
    if (r && r.status && r.status !== "falhou") {
      await fecharEnvio(origem, msg.id, msg.telefone, msg.container, r.status);
      return;
    }
    responder(origem, msg.id, "erro", "abrir");
  } catch (x) {
    responder(origem, msg.id, "erro", "aba");
  }
}

// Envio um por um: abre a conversa na aba do WhatsApp Web daquele número (sem
// aba nova) e traz essa aba para a frente.
async function abrir(msg) {
  const store = (await cookieStoreDe(msg.container)) || "firefox-default";
  const url = `https://web.whatsapp.com/send?phone=${msg.telefone}${msg.texto ? `&text=${encodeURIComponent(msg.texto)}` : ""}`;
  try {
    const abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*", cookieStoreId: store });
    if (abas.length) {
      const aba = await browser.tabs.update(abas[0].id, { active: true });
      if (aba && aba.windowId != null) await browser.windows.update(aba.windowId, { focused: true });
      // Tenta abrir por dentro (sem recarregar); se não der, recarrega.
      const r = await browser.tabs.sendMessage(abas[0].id, { tipo: "abrir-conversa", telefone: msg.telefone, texto: msg.texto || "" }).catch(() => null);
      if (!r || r.status === "falhou") await browser.tabs.update(abas[0].id, { url });
    } else {
      await browser.tabs.create({ url, cookieStoreId: store, active: true });
    }
  } catch (e) {}
}

// Cria o container do número se ele ainda não existir neste Firefox.
async function garantirContainer(nome) {
  const existente = await cookieStoreDe(nome);
  if (existente) return existente;
  const novo = await browser.contextualIdentities.create({ name: nome, color: "green", icon: "briefcase" });
  return novo.cookieStoreId;
}

// Abre o WhatsApp Web de cada número no container dele, em aba fixada.
// Se a aba já existe, só fixa; não abre outra.
async function abrirTodos(nomes) {
  for (const nome of nomes || []) {
    try {
      const store = await garantirContainer(nome);
      const abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*", cookieStoreId: store });
      if (abas.length) await browser.tabs.update(abas[0].id, { pinned: true });
      else await browser.tabs.create({ url: "https://web.whatsapp.com/", cookieStoreId: store, pinned: true, active: false });
    } catch (e) {}
  }
  return { ok: true };
}

// Situação de cada número: conectado, qr, carregando, fechado ou sem-container.
async function estados(nomes) {
  const lista = [];
  for (const nome of nomes || []) {
    let estado = "fechado";
    try {
      // Chrome: um WhatsApp Web só, o mesmo para qualquer número do Meu Radar.
      const abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*" });
      if (abas.length) {
        const r = await browser.tabs.sendMessage(abas[0].id, { tipo: "estado" }).catch(() => null);
        estado = (r && r.estado) || "carregando";
      }
    } catch (e) {}
    lista.push({ container: nome, estado });
  }
  return lista;
}

async function irPara(nome) {
  const store = await cookieStoreDe(nome);
  if (!store) return;
  const abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*", cookieStoreId: store });
  if (abas.length) {
    const aba = await browser.tabs.update(abas[0].id, { active: true });
    if (aba && aba.windowId != null) await browser.windows.update(aba.windowId, { focused: true });
  } else {
    await abrirTodos([nome]);
    const novas = await browser.tabs.query({ url: "https://web.whatsapp.com/*", cookieStoreId: await cookieStoreDe(nome) });
    if (novas.length) await browser.tabs.update(novas[0].id, { active: true });
  }
}

// ---- Ligações pelo WhatsApp: guarda e entrega ao Meu Radar ----
const RADAR = "https://meu-radar-chrome-61a2722e.base44.app/*";
async function pendentes() {
  return (await browser.storage.local.get("ligacoesWA")).ligacoesWA || [];
}
async function entregar() {
  const lista = await pendentes();
  if (!lista.length) return;
  const abas = await browser.tabs.query({ url: RADAR });
  for (const aba of abas) {
    for (const l of lista) browser.tabs.sendMessage(aba.id, { tipo: "ligacao-wa", ligacao: l }).catch(() => {});
  }
}
async function guardarLigacao(l, sender) {
  try {
    if (sender && sender.tab && sender.tab.cookieStoreId && sender.tab.cookieStoreId !== "firefox-default") {
      const c = await browser.contextualIdentities.get(sender.tab.cookieStoreId);
      l.container = c ? c.name : "";
    }
  } catch (e) {}
  const lista = await pendentes();
  if (!lista.find((x) => x.id === l.id)) lista.push(l);
  await browser.storage.local.set({ ligacoesWA: lista.slice(-200) });
  entregar();
}
async function confirmarLigacao(id) {
  const lista = (await pendentes()).filter((x) => x.id !== id);
  await browser.storage.local.set({ ligacoesWA: lista });
}

// ---- Mensagens do WhatsApp: guarda e entrega ao Meu Radar ----
async function filaMsg() { return (await browser.storage.local.get("mensagensWA")).mensagensWA || []; }
async function entregarMsgs() {
  const lista = await filaMsg();
  if (!lista.length) return;
  const abas = await browser.tabs.query({ url: RADAR });
  for (const aba of abas) {
    for (let i = 0; i < lista.length; i += 50) browser.tabs.sendMessage(aba.id, { tipo: "mensagens-wa", mensagens: lista.slice(i, i + 50) }).catch(() => {});
  }
}
async function guardarMsgs(ms, sender) {
  let container = "";
  try {
    if (sender && sender.tab && sender.tab.cookieStoreId && sender.tab.cookieStoreId !== "firefox-default") {
      const c = await browser.contextualIdentities.get(sender.tab.cookieStoreId);
      container = c ? c.name : "";
    }
  } catch (e) {}
  const lista = await filaMsg();
  const ids = new Set(lista.map((x) => x.id));
  const novas = [];
  (ms || []).forEach((m) => { if (!ids.has(m.id)) { const x = { ...m, container }; lista.push(x); novas.push(x); } });
  await browser.storage.local.set({ mensagensWA: lista.slice(-3000) });
  // Manda só as novas; a fila inteira só é reenviada quando o Meu Radar abre.
  if (novas.length) {
    const abas = await browser.tabs.query({ url: RADAR });
    for (const aba of abas) browser.tabs.sendMessage(aba.id, { tipo: "mensagens-wa", mensagens: novas }).catch(() => {});
  }
}
async function confirmarMsgs(ids) {
  const s = new Set(ids || []);
  await browser.storage.local.set({ mensagensWA: (await filaMsg()).filter((x) => !s.has(x.id)) });
}

// ---- Reunião agendada na página da Nibo: avisa o Meu Radar ----
const dataPorAba = new Map();
async function filaReunioes() { return (await browser.storage.local.get("reunioesAg")).reunioesAg || []; }
async function entregarReunioes() {
  const lista = await filaReunioes();
  if (!lista.length) return;
  const abas = await browser.tabs.query({ url: RADAR });
  for (const aba of abas) for (const r of lista) browser.tabs.sendMessage(aba.id, { tipo: "reuniao-agendada", reuniao: r }).catch(() => {});
}
async function reuniaoConcluida(msg, sender) {
  const aba = sender && sender.tab ? sender.tab.id : -1;
  const info = { ...(dataPorAba.get(aba) || {}) };
  if (msg.data) { info.data = msg.data; info.inicio = msg.inicio; info.fim = msg.fim; }
  if (msg.consultor) info.consultor = msg.consultor;
  let email = msg.email || info.email || "";
  if (!email && aba >= 0) {
    try { const r = await browser.tabs.sendMessage(aba, { tipo: "agenda-qual-email" }, { frameId: 0 }); email = (r && r.email) || ""; } catch (e) {}
  }
  if (!email || !info.data) { dataPorAba.set(aba, { ...info, email, pendente: true }); return; }
  const id = "reuniao-" + email.toLowerCase() + "-" + info.data + "-" + info.inicio;
  const lista = await filaReunioes();
  if (!lista.find((x) => x.id === id)) lista.push({ id, email, data: info.data, inicio: info.inicio, fim: info.fim, consultor: info.consultor || "", quando: new Date().toISOString() });
  await browser.storage.local.set({ reunioesAg: lista.slice(-100) });
  dataPorAba.delete(aba);
  entregarReunioes();
  if (aba >= 0) setTimeout(async () => { await browser.tabs.remove(aba).catch(() => {}); focarRadar(); }, 3000);
}
// Reunião lida na lista "Reuniões agendadas" do contato: avisa o Radar com a
// mais recente, sem fechar a aba (você pode estar só consultando).
async function reuniaoDaLista(msg) {
  const email = String(msg.email || "").trim();
  if (!email || !msg.data || !msg.inicio) return;
  const id = "reuniao-" + email.toLowerCase() + "-" + msg.data + "-" + msg.inicio;
  const lista = await filaReunioes();
  const ja = lista.find((x) => x.id === id);
  if (ja) {
    if (!ja.consultor && msg.consultor) ja.consultor = msg.consultor;
  } else {
    lista.push({ id, email, data: msg.data, inicio: msg.inicio, fim: msg.fim || "", consultor: msg.consultor || "", quando: new Date().toISOString() });
  }
  await browser.storage.local.set({ reunioesAg: lista.slice(-100) });
  entregarReunioes();
}
async function confirmarReuniao(id) {
  await browser.storage.local.set({ reunioesAg: (await filaReunioes()).filter((x) => x.id !== id) });
}

// ---- HubSpot: conferir proprietário (busca em janela minimizada) e subir negócio ----
const HS_BUSCA = "https://app.hubspot.com/contacts/1554114/objects/0-1/views/all/list?query=";
const HS_FORM = "https://share.hsforms.com/1fLSwVYMLTMeQc5dURO4DvQxb5u";
const semAcento = (t) => String(t || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z ]/g, " ").replace(/\s+/g, " ").trim();
const ehMeu = (dono, meuNome, emailDono, meuEmail) => {
  if (emailDono && meuEmail) return emailDono.toLowerCase() === String(meuEmail).toLowerCase();
  const d = semAcento(dono), partes = semAcento(meuNome).split(" ").filter((x) => x.length > 2);
  return !!d && partes.length > 0 && partes.every((p) => d.split(" ").includes(p));
};
let filaHs = Promise.resolve();
async function focarRadar() {
  const abas = await browser.tabs.query({ url: RADAR });
  if (!abas.length) return;
  await browser.tabs.update(abas[0].id, { active: true }).catch(() => {});
  await browser.windows.update(abas[0].windowId, { focused: true }).catch(() => {});
}
async function lerBusca(tabId, url) {
  await browser.tabs.update(tabId, { url });
  const fim = Date.now() + 45000;
  await new Promise((r) => setTimeout(r, 2500));
  while (Date.now() < fim) {
    try {
      const r = await browser.tabs.sendMessage(tabId, { tipo: "hs-ler-busca", espera: Math.max(3000, fim - Date.now()) });
      if (r) return r;
    } catch (e) {}
    try { const t = await browser.tabs.get(tabId); if (/login|signin/i.test(t.url || "")) return { estado: "login" }; } catch (e) { return { estado: "erro" }; }
    await new Promise((r) => setTimeout(r, 1000));
  }
  return { estado: "tempo" };
}
function conferirHubspot(msg, fase) {
  filaHs = filaHs.then(async () => {
    const termos = [];
    (msg.emails || []).filter(Boolean).forEach((e) => termos.push({ por: "email", q: String(e).trim().toLowerCase() }));
    (msg.telefones || []).filter(Boolean).forEach((t) => { const d = String(t).replace(/\D/g, ""); if (d.length >= 10) termos.push({ por: "telefone", q: d.startsWith("55") && d.length > 11 ? d.slice(2) : d }); });
    const base = { tipo: "hubspot-resultado", pedido: msg.pedido, leadId: msg.leadId, fase: fase || "antes" };
    if (!termos.length) { paraRadar({ ...base, status: "sem-dados" }); return; }
    let aba = null;
    try {
      // Conferência numa aba nova, ao lado do Meu Radar, sem tirar você da tela; fecha sozinha no fim.
      const radar = (await browser.tabs.query({ url: RADAR }))[0];
      aba = await browser.tabs.create({ url: "about:blank", active: false, windowId: radar ? radar.windowId : undefined, index: radar ? radar.index + 1 : undefined });
      const tabId = aba.id;
      for (const t of termos) {
        const r = await lerBusca(tabId, HS_BUSCA + encodeURIComponent(t.q));
        if (r.estado === "login") { paraRadar({ ...base, status: "login" }); return; }
        if (r.estado === "tempo" || r.estado === "erro") {
          if (!msg._repetiu) { msg._repetiu = true; setTimeout(() => conferirHubspot(msg, fase), 1500); return; }
          paraRadar({ ...base, status: "erro" }); return;
        }
        if (r.estado === "achou" && r.contatos.length) {
          const outro = r.contatos.find((c) => c.proprietario && !ehMeu(c.proprietario, msg.meuNome, c.emailDono, msg.meuEmail));
          const meu = r.contatos.find((c) => c.proprietario && ehMeu(c.proprietario, msg.meuNome, c.emailDono, msg.meuEmail));
          // Se algum contato do resultado já é seu, o lead é seu: outros contatos do mesmo e-mail (ex.: outra pessoa do escritório em Lost) não barram.
          const c = meu || outro || r.contatos[0];
          let status = meu ? "seu" : outro ? "outro" : "livre", etapa = "";
          if (!meu && outro && c.link) {
            // Com outra pessoa: abre o contato para ver a etapa do negócio (Lost libera criar; outra etapa bloqueia).
            await browser.tabs.update(tabId, { url: c.link });
            await new Promise((ok) => setTimeout(ok, 2500));
            let e = null;
            for (let i = 0; i < 20 && !e; i++) {
              try { e = await browser.tabs.sendMessage(tabId, { tipo: "hs-ler-contato", espera: 20000 }); } catch (x) { await new Promise((ok) => setTimeout(ok, 1000)); }
            }
            const etapas = (e && e.etapas) || [];
            const lost = (x) => /lost|perdid/i.test(x);
            if (etapas.length && etapas.every(lost)) status = "outro-lost";
            else if (etapas.length) status = "outro-ativo";
            etapa = etapas.find((x) => !lost(x)) || etapas[0] || "";
          }
          paraRadar({ ...base, status, proprietario: c.proprietario || "", link: c.link || "", etapa, por: t.por });
          return;
        }
      }
      paraRadar({ ...base, status: "livre", proprietario: "", link: "", por: "" });
    } catch (e) {
      if (!msg._repetiu) { msg._repetiu = true; setTimeout(() => conferirHubspot(msg, fase), 1500); }
      else paraRadar({ ...base, status: "erro" });
    } finally {
      if (aba) browser.tabs.remove(aba.id).catch(() => {});
    }
  });
  return filaHs;
}
const formPendente = new Map(); // tabId -> pedido
let ultimoForm = null;
const fmtTel = (t) => { let d = String(t || "").replace(/\D/g, ""); if (d.startsWith("55") && d.length > 11) d = d.slice(2); if (d.length === 11) return "(" + d.slice(0, 2) + ")" + d.slice(2, 7) + "-" + d.slice(7); if (d.length === 10) return "(" + d.slice(0, 2) + ")" + d.slice(2, 6) + "-" + d.slice(6); return d; };
const fmtCnpj = (c) => { const d = String(c || "").replace(/\D/g, ""); return d.length === 14 ? d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5") : d; };
const titulo = (t) => String(t || "").toLowerCase().split(" ").map((w, i) => (i > 0 && /^(da|de|do|das|dos|e)$/.test(w)) ? w : w.replace(/^\S/, (x) => x.toUpperCase())).join(" ").replace(/\b(Me|Epp|S\/s)\b/g, (x) => x.toUpperCase());
async function abrirFormulario(msg) {
  const d = msg.dados || {};
  const dados = {
    sdr: d.sdr || "", nome: titulo(d.nome), email: String(d.email || "").toLowerCase(), whatsapp: fmtTel(d.whatsapp),
    outro: fmtTel(d.outro), empresa: titulo(String(d.empresa || "").replace(/\s*\(.*\)\s*$/, "")), cnpj: fmtCnpj(d.cnpj),
    estado: String(d.estado || "").toUpperCase(), cidade: titulo(d.cidade),
  };
  const tab = await browser.tabs.create({ url: HS_FORM, active: true });
  const p = { pedido: msg.pedido, leadId: msg.leadId, dados, conferir: msg.conferir || null, criado: Date.now() };
  formPendente.set(tab.id, p);
  ultimoForm = p;
}
async function formEnviado(sender) {
  const tabId = sender && sender.tab ? sender.tab.id : -1;
  const p = formPendente.get(tabId) || ultimoForm;
  if (!p || p.avisado) return;
  p.avisado = true;
  formPendente.delete(tabId);
  paraRadar({ tipo: "hubspot-negocio-enviado", pedido: p.pedido, leadId: p.leadId });
  setTimeout(async () => { if (tabId >= 0) await browser.tabs.remove(tabId).catch(() => {}); focarRadar(); }, 2500);
  if (p.conferir) [60, 180, 300, 600].forEach((s, i) => setTimeout(() => conferirHubspot({ ...p.conferir, pedido: p.pedido, leadId: p.leadId }, "depois-" + (i + 1)), s * 1000));
}
async function paraRadar(msg) {
  const abas = await browser.tabs.query({ url: RADAR });
  for (const aba of abas) browser.tabs.sendMessage(aba.id, msg).catch(() => {});
}
async function puxarConversa(msg) {
  // Chrome: um WhatsApp Web só, sem containers.
  const store = await cookieStoreDe(msg.container);
  let abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*", cookieStoreId: store });
  if (!abas.length) { await abrirTodos([msg.container]); await new Promise((r) => setTimeout(r, 8000)); abas = await browser.tabs.query({ url: "https://web.whatsapp.com/*", cookieStoreId: store }); }
  if (!abas.length) return paraRadar({ tipo: "puxar-fim", pedido: msg.pedido, ok: false, motivo: "aba" });
  const r = await browser.tabs.sendMessage(abas[0].id, { tipo: "puxar", telefone: msg.telefone, pedido: msg.pedido }).catch(() => null);
  paraRadar({ tipo: "puxar-fim", pedido: msg.pedido, ok: !!(r && r.ok), lidas: r ? r.lidas : 0, motivo: r ? r.motivo : "erro" });
}

browser.runtime.onMessage.addListener((msg, sender) => {
  if (msg.tipo === "mensagens-wa") return guardarMsgs(msg.mensagens, sender).then(() => ({ ok: true }));
  if (msg.tipo === "mensagens-ok") return confirmarMsgs(msg.ids).then(() => ({ ok: true }));
  if (msg.tipo === "pedir-mensagens") return entregarMsgs().then(() => ({ ok: true }));
  if (msg.tipo === "nao-lidas") return paraRadar({ tipo: "nao-lidas", telefones: msg.telefones }).then(() => ({ ok: true }));
  if (msg.tipo === "respostas") {
    return (async () => {
      let container = "";
      try {
        if (sender && sender.tab && sender.tab.cookieStoreId && sender.tab.cookieStoreId !== "firefox-default") {
          const c = await browser.contextualIdentities.get(sender.tab.cookieStoreId);
          container = c ? c.name : "";
        }
      } catch (e) {}
      await paraRadar({ tipo: "respostas", container, itens: msg.itens || [] });
      return { ok: true };
    })();
  }
  if (msg.tipo === "puxar-progresso") return paraRadar(msg).then(() => ({ ok: true }));
  if (msg.tipo === "puxar-conversa") { puxarConversa(msg); return Promise.resolve({ ok: true }); }
  if (msg.tipo === "ligacao-wa") return guardarLigacao(msg.ligacao, sender).then(() => ({ ok: true }));
  if (msg.tipo === "ligacao-ok") return confirmarLigacao(msg.id).then(() => ({ ok: true }));
  if (msg.tipo === "agenda-data") {
    const aba = sender && sender.tab ? sender.tab.id : -1;
    const atual = dataPorAba.get(aba) || {};
    dataPorAba.set(aba, { ...atual, data: msg.data, inicio: msg.inicio, fim: msg.fim });
    if (atual.pendente) reuniaoConcluida({}, sender);
    return Promise.resolve({ ok: true });
  }
  if (msg.tipo === "agenda-concluida") return reuniaoConcluida(msg, sender).then(() => ({ ok: true }));
  if (msg.tipo === "agenda-lista") return reuniaoDaLista(msg).then(() => ({ ok: true }));
  if (msg.tipo === "reuniao-ok") return confirmarReuniao(msg.id).then(() => ({ ok: true }));
  if (msg.tipo === "hubspot-conferir") { conferirHubspot(msg, "antes"); return Promise.resolve({ ok: true }); }
  if (msg.tipo === "hubspot-negocio") return abrirFormulario(msg).then(() => ({ ok: true }));
  if (msg.tipo === "hsform-dados") {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const p = formPendente.get(tabId) || (ultimoForm && Date.now() - ultimoForm.criado < 600000 ? ultimoForm : null);
    return Promise.resolve({ dados: p ? p.dados : null });
  }
  if (msg.tipo === "hsform-enviado") return formEnviado(sender).then(() => ({ ok: true }));
  if (msg.tipo === "pedir-reunioes") return entregarReunioes().then(() => ({ ok: true }));
  if (msg.tipo === "pedir-ligacoes") return entregar().then(() => ({ ok: true }));
  if (msg.tipo === "abrir-todos") return abrirTodos(msg.containers);
  if (msg.tipo === "status") return estados(msg.containers).then((lista) => ({ lista }));
  if (msg.tipo === "ir-para") return irPara(msg.container).then(() => ({ ok: true }));
  const aba = sender.tab ? sender.tab.id : null;
  if (msg.tipo === "abrir") {
    abrir(msg);
    return;
  }
  if (msg.tipo === "enviar") {
    enviar(msg, aba);
    return;
  }
  if (msg.tipo === "minha-tarefa") {
    const t = tarefas.get(aba);
    return Promise.resolve(t ? { id: t.id, telefone: t.telefone } : null);
  }
  if (msg.tipo === "resultado") {
    const t = tarefas.get(aba);
    if (t && t.id === msg.id) {
      tarefas.delete(aba);
      clearTimeout(t.timer);
      fecharEnvio(t.origem, t.id, t.telefone, t.container, msg.status, msg.motivo || "");
    }
  }
});
