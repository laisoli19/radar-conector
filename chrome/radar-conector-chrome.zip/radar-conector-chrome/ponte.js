// Radar Conector: avisa o Meu Radar que a extensão está instalada e leva os
// pedidos de envio da página para a extensão (e as respostas de volta).
(() => {
  try {
    document.documentElement.dataset.radarConector = browser.runtime.getManifest().version;
  } catch (e) {}
  const pronto = () => window.postMessage({ de: "radar-conector", tipo: "pronto" }, "*");
  pronto();
  // Chrome: a parte da extensão que roda por trás "dorme" depois de uns 30 s
  // parada. Enquanto o Meu Radar está aberto, um sinal a cada 20 s a mantém
  // acordada (disparo, HubSpot e agendamento não se perdem no meio).
  setInterval(() => {
    try { browser.runtime.sendMessage({ tipo: "manter-acordado" }).catch(() => {}); } catch (e) {}
  }, 20000);
  setTimeout(() => {
    browser.runtime.sendMessage({ tipo: "pedir-ligacoes" }).catch(() => {});
    browser.runtime.sendMessage({ tipo: "pedir-mensagens" }).catch(() => {});
    browser.runtime.sendMessage({ tipo: "pedir-reunioes" }).catch(() => {});
  }, 3000);
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const d = e.data || {};
    if (d.para !== "radar-conector") return;
    if (d.tipo === "ping") pronto();
    if (d.tipo === "abrir") {
      browser.runtime.sendMessage({
        tipo: "abrir",
        telefone: String(d.telefone || ""),
        texto: String(d.texto || ""),
        container: String(d.container || ""),
      });
    }
    if (d.tipo === "abrir-todos" || d.tipo === "status" || d.tipo === "ir-para") {
      const pedido = { tipo: d.tipo };
      if (d.tipo === "ir-para") pedido.container = String(d.container || "");
      else pedido.containers = (Array.isArray(d.containers) ? d.containers : []).map(String);
      browser.runtime
        .sendMessage(pedido)
        .then((r) => window.postMessage({ de: "radar-conector", tipo: d.tipo, id: d.id, ...(r || {}) }, "*"))
        .catch(() => window.postMessage({ de: "radar-conector", tipo: d.tipo, id: d.id, erro: true }, "*"));
    }
    if (d.tipo === "mensagens-ok") {
      browser.runtime.sendMessage({ tipo: "mensagens-ok", ids: Array.isArray(d.ids) ? d.ids.map(String) : [] }).catch(() => {});
    }
    if (d.tipo === "pedir-mensagens") {
      browser.runtime.sendMessage({ tipo: "pedir-mensagens" }).catch(() => {});
    }
    if (d.tipo === "puxar-conversa") {
      browser.runtime.sendMessage({ tipo: "puxar-conversa", telefone: String(d.telefone || "").replace(/\D/g, ""), container: String(d.container || ""), pedido: String(d.pedido || "") }).catch(() => {});
    }
    if (d.tipo === "hubspot-conferir") {
      browser.runtime.sendMessage({ tipo: "hubspot-conferir", pedido: String(d.pedido || ""), leadId: String(d.leadId || ""), emails: (d.emails || []).map(String), telefones: (d.telefones || []).map(String), meuNome: String(d.meuNome || ""), meuEmail: String(d.meuEmail || "") }).catch(() => {});
    }
    if (d.tipo === "hubspot-negocio") {
      browser.runtime.sendMessage({ tipo: "hubspot-negocio", pedido: String(d.pedido || ""), leadId: String(d.leadId || ""), dados: d.dados || {}, conferir: d.conferir || null }).catch(() => {});
    }
    if (d.tipo === "reuniao-ok") {
      browser.runtime.sendMessage({ tipo: "reuniao-ok", id: String(d.id || "") }).catch(() => {});
    }
    if (d.tipo === "pedir-reunioes") {
      browser.runtime.sendMessage({ tipo: "pedir-reunioes" }).catch(() => {});
    }
    if (d.tipo === "ligacao-ok") {
      browser.runtime.sendMessage({ tipo: "ligacao-ok", id: String(d.id || "") }).catch(() => {});
    }
    if (d.tipo === "pedir-ligacoes") {
      browser.runtime.sendMessage({ tipo: "pedir-ligacoes" }).catch(() => {});
    }
    if (d.tipo === "enviar") {
      browser.runtime.sendMessage({
        tipo: "enviar",
        id: d.id,
        telefone: String(d.telefone || ""),
        texto: String(d.texto || ""),
        container: String(d.container || ""),
      });
    }
  });
  browser.runtime.onMessage.addListener((msg) => {
    if (msg.tipo === "mensagens-wa" || msg.tipo === "nao-lidas" || msg.tipo === "respostas" || msg.tipo === "puxar-progresso" || msg.tipo === "puxar-fim") {
      const { tipo, ...resto } = msg;
      window.postMessage({ de: "radar-conector", tipo, ...resto }, "*");
    }
    if (msg.tipo === "hubspot-resultado" || msg.tipo === "hubspot-negocio-enviado") {
      const { tipo, ...resto } = msg;
      window.postMessage({ de: "radar-conector", tipo, ...resto }, "*");
    }
    if (msg.tipo === "reuniao-agendada") {
      window.postMessage({ de: "radar-conector", tipo: "reuniao-agendada", reuniao: msg.reuniao }, "*");
    }
    if (msg.tipo === "ligacao-wa") {
      window.postMessage({ de: "radar-conector", tipo: "ligacao-wa", ligacao: msg.ligacao }, "*");
    }
    if (msg.tipo === "resultado") {
      window.postMessage({ de: "radar-conector", tipo: "resultado", id: msg.id, status: msg.status, motivo: msg.motivo, container: msg.container }, "*");
    }
  });
})();
