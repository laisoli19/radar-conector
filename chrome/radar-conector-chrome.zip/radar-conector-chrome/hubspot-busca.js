// Radar Conector: lista de contatos do HubSpot (busca). Lê nome, e-mail,
// proprietário e link de cada linha quando o Radar Conector pede.
(() => {
  const limpa = (t) => String(t || "").replace(/[​-‍﻿]/g, "").replace(/\s+/g, " ").trim();
  // Tela vazia da busca: "Nenhum(a) Contatos corresponde aos filtros atuais." (ou em inglês).
  const VAZIO = /nenhum(\(a\))?\s*(contatos?|registros?|resultados?)\s*(corresponde|encontrad)|corresponde aos filtros|no (contacts|records|results) (match|found)|n[aã]o encontramos/i;
  const cabecalhos = () => [...document.querySelectorAll("th, [role='columnheader']")];
  const indiceDe = (re) => cabecalhos().findIndex((h) => re.test(limpa(h.textContent)));
  const linhas = () => {
    let ls = [...document.querySelectorAll("tbody tr")];
    if (!ls.length) ls = [...document.querySelectorAll("[role='row']")].filter((r) => !r.querySelector("th, [role='columnheader']"));
    return ls.filter((r) => r.querySelector("a[href*='/record/0-1/'], a[href*='/contact/']"));
  };
  const celulas = (r) => [...r.querySelectorAll("td, [role='gridcell'], [role='cell']")];
  const esqueleto = (el) => !!el && (!limpa(el.textContent) || !!el.querySelector("[class*='skeleton' i], [class*='loading' i], [class*='placeholder' i]"));
  const ler = () => {
    if (/login|signin/i.test(location.hostname + location.pathname)) return { estado: "login" };
    const ls = linhas();
    if (!ls.length) {
      const txt = limpa(document.body && document.body.innerText);
      if (VAZIO.test(txt)) return { estado: "vazio" };
      return null; // ainda carregando
    }
    const iDono = indiceDe(/propriet[aá]rio do contato|contact owner/i);
    if (iDono < 0) return null;
    const iDonoNaLinha = (r) => {
      // a primeira coluna (caixa de seleção) às vezes não é célula; alinha pelo número de cabeçalhos
      const cs = celulas(r), hs = cabecalhos();
      const desloc = hs.length - cs.length;
      return cs[iDono - desloc];
    };
    const res = [];
    for (const r of ls) {
      const c = iDonoNaLinha(r);
      if (!c || esqueleto(c)) return null; // proprietário ainda carregando
      const a = r.querySelector("a[href*='/record/0-1/'], a[href*='/contact/']");
      // Texto da célula sem as iniciais do avatar ("FD", "LS") e sem o e-mail entre parênteses.
      const avatar = c.querySelector("[class*='avatar' i], [data-test-id*='avatar' i]");
      let bruto = limpa(c.textContent);
      if (avatar && limpa(avatar.textContent) && bruto.startsWith(limpa(avatar.textContent))) bruto = limpa(bruto.slice(limpa(avatar.textContent).length));
      bruto = bruto.replace(/^([A-ZÀ-Ú]{1,3})(?=[A-ZÀ-Ú][a-zà-ú])/, "");
      const emailDono = (bruto.match(/[\w.+-]+@[\w-]+(\.[\w-]+)+/) || [""])[0].toLowerCase();
      let dono = limpa(bruto.replace(/\(?\s*[\w.+-]+@[\w-]+(\.[\w-]+)+\s*\)?/, "").replace(/[.…]+$/, ""));
      if (/^(--|—|-|nenhum propriet[aá]rio|no owner|sem propriet[aá]rio)$/i.test(dono)) dono = "";
      res.push({ nome: limpa(a ? a.textContent : ""), proprietario: dono, emailDono, link: a ? new URL(a.getAttribute("href"), location.origin).href : "" });
    }
    return { estado: "achou", contatos: res };
  };
  // Página do contato: etapas dos negócios (ex.: "PV - Perdido - Lost", "PV - Descoberta").
  const lerEtapas = () => {
    const txt = (document.body && document.body.innerText) || "";
    if (!/neg[oó]cios|deals/i.test(txt)) return null;
    const zero = /neg[oó]cios\s*\(0\)|deals\s*\(0\)/i.test(txt);
    const etapas = [...new Set((txt.match(/\bPV\s*-\s*[A-Za-zÀ-ú]+(?:[ ]+[A-Za-zÀ-ú]+)*(?:\s*-\s*Lost)?/g) || []).map(limpa))];
    if (etapas.length) return { etapas };
    if (zero) return { etapas: [] };
    return null;
  };
  browser.runtime.onMessage.addListener((m) => {
    if (m && m.tipo === "hs-ler-contato") {
      return new Promise((ok) => {
        const fim = Date.now() + (m.espera || 25000);
        const tentar = () => { let r = null; try { r = lerEtapas(); } catch (e) {} if (r) return ok(r); if (Date.now() > fim) return ok({ etapas: [], tempo: true }); setTimeout(tentar, 700); };
        tentar();
      });
    }
    if (!m || m.tipo !== "hs-ler-busca") return;
    return new Promise((ok) => {
      const fim = Date.now() + (m.espera || 30000);
      const tentar = () => {
        let r = null;
        try { r = ler(); } catch (e) {}
        if (r) return ok(r);
        if (Date.now() > fim) return ok({ estado: "tempo" });
        setTimeout(tentar, 700);
      };
      tentar();
    });
  });
})();
